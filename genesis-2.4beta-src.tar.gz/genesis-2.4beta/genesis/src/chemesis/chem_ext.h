#include "sim_ext.h"
#include "../newconn/newconn_defs.h"
#define CALCIUM            5
#include "../newconn/newconn_struct.h"
#include "../newconn/fac_struct.h" /* for facsynchan */
#include "../newconn/synaptic_event.h"
#include "../shell/shell_func_ext.h"
#include "../segment/seg_struct.h"  /* for compartment definition */
#include "chem_struct.h"
