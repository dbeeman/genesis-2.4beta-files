/*
** $Id: system_deps.h,v 1.1.1.1 2005/06/14 04:38:32 svitak Exp $
** $Log: system_deps.h,v $
** Revision 1.1.1.1  2005/06/14 04:38:32  svitak
** Import from snapshot of CalTech CVS tree of June 8, 2005
**
** Revision 1.2  1995/04/14 18:06:03  dhb
** This file is essentially the same as sys/system_deps.h so it
** now just includes that file.
**
** Revision 1.1  1992/12/11  19:05:12  dhb
** Initial revision
**
*/

#include "../sys/system_deps.h"
