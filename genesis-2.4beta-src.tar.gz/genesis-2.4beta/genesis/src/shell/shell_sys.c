static char rcsid[] = "$Id: shell_sys.c,v 1.2 2005/06/26 08:25:37 svitak Exp $";

/*
** $Log: shell_sys.c,v $
** Revision 1.2  2005/06/26 08:25:37  svitak
** Provided explicit types for untyped funtions. Fixed return statements to
** match return type.
**
** Revision 1.1.1.1  2005/06/14 04:38:34  svitak
** Import from snapshot of CalTech CVS tree of June 8, 2005
**
** Revision 1.1  1992/12/11 19:04:48  dhb
** Initial revision
**
*/

void simsystem(string)
char	*string;
{
}
