static char* rcsid = "$Id: null_startup.c,v 1.2 2005/06/26 08:25:37 svitak Exp $";

/*
** $Log: null_startup.c,v $
** Revision 1.2  2005/06/26 08:25:37  svitak
** Provided explicit types for untyped funtions. Fixed return statements to
** match return type.
**
** Revision 1.1.1.1  2005/06/14 04:38:34  svitak
** Import from snapshot of CalTech CVS tree of June 8, 2005
**
** Revision 1.1  1994/03/21 04:47:55  dhb
** Initial revision
**
*/

void STARTUP_shell() {
}
