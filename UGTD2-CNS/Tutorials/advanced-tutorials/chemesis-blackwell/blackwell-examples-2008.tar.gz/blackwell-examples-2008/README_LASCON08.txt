Tutorial scripts to teach how to develop models of second messengers
and calcium dynamics.

Tutorial08.g is a script that builds the three biochemical reactions on
slides 12-14 in the presentation "Modelling Biochemical Reactions"
(Lascon2biochemTutorial.ppt) at LASCON 2 in Ribeirao Preto, Brazil in July
of 2008. It uses parameters in param.g, and graphs for illustration are
created in graphs.g.

Reactions are also implemented in mGlu-IP3-enz.g.  Top level file is called
PurkCell.g. This file has an alternative mmenz implementation of IP3
production, and reveals that the mmenz formulation is not valid.  It also
has degradation of IP3 and aG (active GalphaGTP).  The same reactions are
also programmed for xppaut, in the file mglu-ip3.ode.

CALx.g are a series of 6 scripts that build up calcium dynamics in a step
by step manner.  It implements the model shown in slides 15-19 of the
presentation "Modelling Calcium Concentration"
(Lascon2calciumTutorial.ppt), and uses most of the chemesis2.1 objects
explained.

cal1.g creates a single compartment with interaction between calcium and
buffer

cal2.g creates a two compartment model: dendrite and soma.  The calcium -
buffer reaction is set up in each compartment in a function called cabuf,
which implements the pools and reaction introduced in cal1.g.  The function
simplies the code, so it doesn't have to be repeated once for each
compartment. One additional object/element is required to allow for
diffusion between compartments.

cal3.g creates the two compartment model of cal2.g, and then adds ip3
induced calcium release into the soma.  Within cal3.g, two of the release
elements are created, for illustrative purposes.  The remaining elements
are created in a function that is called.

cal4.g adds a SERCA pump to the model in cal3.g in order to more quickly
re-establish calcium equilibrium.

cal5.g is a two compartment model with a voltage dependent calcium
channels, but no calcium release.  It uses the Goldman-Hodgkin-Katz
formulation for driving potential.  It activates the channel by
depolarizing the cell with current injection.

cal6.g implements cal5.g using only genesis objects.  It uses Ca_concen for
the calcium pool and decay.  It uses tabchennels for the calcium current.
There is no diffusion from soma to dendrite because Ca_concen doesn't allow
for diffusion.
