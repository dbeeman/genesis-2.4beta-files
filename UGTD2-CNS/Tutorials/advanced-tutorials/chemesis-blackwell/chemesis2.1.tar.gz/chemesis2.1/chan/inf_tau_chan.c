/* inf_tau_chan.c */
/* Avrama Blackwell, GMU, Oct 1997 */
/* A modification of the program hh_channel.c by the following people */
/* M.Nelson Caltech 8/88 */
/* E. De Schutter Caltech 1/91, added SAVE2/RESTORE2 */
/* U.S. Bhalla Caltech 2/91, added CALC_ALPHA, CALC_BETA, CALC_MINF */

/* This  program computes voltage dependent channel currents given
the parameters specified as inf (steady state value) and tau (time const) */

#include "chan_ext.h"

#define Field(F) (channel->F)

inf_tau_chan(channel,action)
register struct vdep_chan_type *channel;
Action      *action;
{
  double v;
  double xrest;
  double yrest;
  double A,B;
  double dt;
  MsgIn  *msg;
  double savedata[2];
  int     n;                      /* for counting messages */

  if (debug > 1) {
     ActionHeader("inf_tau_chan", channel,action);
  }

  SELECT_ACTION(action){ 
  case INIT:
    channel->activation = 0;
    break;
  case PROCESS:
     MSGLOOP(channel,msg) {
       case 0: /* compartment */
               /* 0 = membrane potential */
               v = MSGVALUE(msg,0);
	       Field(Vm) = v;
               break;
      }

      dt = Clockrate(channel);

      /* calculate the state variables activation (X) and inactivation (Y) */

      if(Field(act_power) != 0){
	 vdep_rate_const (&channel->act_ss.rate_const, v, 
		channel->act_ss.min,
		channel->act_ss.max,
		channel->act_ss.v0,
		channel->act_ss.slope,
		channel->act_ss.in_exp_power,
		channel->act_ss.out_exp_power,
		channel->act_ss.in_exp_offset,
		channel->act_ss.out_exp_offset);
		
	vdep_rate_const (&channel->act_tau.rate_const, v, 
		channel->act_tau.min,
		channel->act_tau.max,
		channel->act_tau.v0,
		channel->act_tau.slope,
		channel->act_tau.in_exp_power,
		channel->act_tau.out_exp_power,
		channel->act_tau.in_exp_offset,
		channel->act_tau.out_exp_offset);

       /* Evaluate the derivative using IntegrateMethod, which computes
       *	output = state * exp(-B*dt) + (A/B) * (1 - exp(-B*dt))
       *
       * the explicit integration formula using ss and tau is
       *	output = state * exp(-tau*dt) + inf * (1 - exp(-tau*dt))
       *
       * thus, B = 1/tau and inf = (A/B), i.e. A = B*inf =  inf / tau 
       */

	if (debug > 0)
	  printf (" inf_tau_chan: act_ss.rate_const = %f act_tau.rate_const = %f \n", channel->act_ss.rate_const, channel->act_tau.rate_const);

	A = channel->act_ss.rate_const / channel->act_tau.rate_const;
	if (channel->act_tau.rate_const == 0)
	  Field(act) = channel->act_ss.rate_const;
	else {
	  B = 1/channel->act_tau.rate_const;
	  if (debug > 0)
	    printf (" inf_tau_chan act: A = %f  B = %f dt = %f\n", A, B, dt);
	  Field(act) = 
		IntegrateMethod(channel->object->method,channel,Field(act),A,B,dt,"act");
	}

	if (debug > 0)
	  printf ("inf_tau_chan: act = %f \n", channel->act);

      }
      if(Field(inact_power) != 0){
	 vdep_rate_const (&channel->inact_ss.rate_const, v, 
		channel->inact_ss.min,
		channel->inact_ss.max,
		channel->inact_ss.v0,
		channel->inact_ss.slope,
		channel->inact_ss.in_exp_power,
		channel->inact_ss.out_exp_power,
		channel->inact_ss.in_exp_offset,
		channel->inact_ss.out_exp_offset);
		
	vdep_rate_const (&channel->inact_tau.rate_const, v, 
		channel->inact_tau.min,
		channel->inact_tau.max,
		channel->inact_tau.v0,
		channel->inact_tau.slope,
		channel->inact_tau.in_exp_power,
		channel->inact_tau.out_exp_power,
		channel->inact_tau.in_exp_offset,
		channel->inact_tau.out_exp_offset);

	if (debug > 0)
	  printf (" inf_tau_chan: inact_ss.rate_const = %f inact_tau.rate_const = %f \n", channel->inact_ss.rate_const, channel->inact_tau.rate_const);

	A = channel->inact_ss.rate_const / channel->inact_tau.rate_const;
	B = 1/channel->inact_tau.rate_const;
	Field(inact) = 
		IntegrateMethod(channel->object->method,channel,Field(inact),A,B,dt,"inact");

	if (debug > 0)
	  printf ("inf_tau_chan: inact = %f \n", channel->inact);
        }

/* calculate the conductance and current */

	if(Field(act_power) != 0 && Field(inact_power) != 0){
	    Field(G) = Field(Gbar) * pow(Field(act),Field(act_power)) * 
	    		pow(Field(inact),Field(inact_power));
	} else 
	if(Field(inact_power) == 0) {
	    Field(G) = Field(Gbar) * pow(Field(act),Field(act_power));
	} else {
	    Field(G) = Field(Gbar);
	}

	/* 
	** calculate the transmembrane current 
	*/
	Field(I) = (v - Field(Vr)) * Field(G);

	break;

    case RESET:

     MSGLOOP(channel,msg) {
       case 0: /* compartment */
               /* 0 = membrane potential */
               v = MSGVALUE(msg,0);
	       Field(Vm) = v;
               break;
      }

/* calculate the forward and backward rate constants from v 	*/

      if(Field(act_power) != 0){
	vdep_rate_const (&channel->act_ss.rate_const, v, 
		channel->act_ss.min,
		channel->act_ss.max,
		channel->act_ss.v0,
		channel->act_ss.slope,
		channel->act_ss.in_exp_power,
		channel->act_ss.out_exp_power,
		channel->act_ss.in_exp_offset,
		channel->act_ss.out_exp_offset);

	vdep_rate_const (&channel->act_tau.rate_const, v, 
		channel->act_tau.min,
		channel->act_tau.max,
		channel->act_tau.v0,
		channel->act_tau.slope,
		channel->act_tau.in_exp_power,
		channel->act_tau.out_exp_power,
		channel->act_tau.in_exp_offset,
		channel->act_tau.out_exp_offset);

	channel->act = channel->act_ss.rate_const;
      }
      if(Field(inact_power) != 0){
	 vdep_rate_const (&channel->inact_ss.rate_const, v, 
		channel->inact_ss.min,
		channel->inact_ss.max,
		channel->inact_ss.v0,
		channel->inact_ss.slope,
		channel->inact_ss.in_exp_power,
		channel->inact_ss.out_exp_power,
		channel->inact_ss.in_exp_offset,
		channel->inact_ss.out_exp_offset);

	 vdep_rate_const (&channel->inact_tau.rate_const, v, 
		channel->inact_tau.min,
		channel->inact_tau.max,
		channel->inact_tau.v0,
		channel->inact_tau.slope,
		channel->inact_tau.in_exp_power,
		channel->inact_tau.out_exp_power,
		channel->inact_tau.in_exp_offset,
		channel->inact_tau.out_exp_offset);

	  channel->inact = channel->inact_ss.rate_const;
     }

/* calculate the conductance and current */

	if(Field(act_power) != 0 && Field(inact_power) != 0){
	    Field(G) = Field(Gbar) * pow(Field(act),Field(act_power)) * 
	    		pow(Field(inact),Field(inact_power));
	} else 
	if(Field(inact_power) == 0) {
	    Field(G) = Field(Gbar) * pow(Field(act),Field(act_power));
	} else {
	    Field(G) = Field(Gbar);
	}

	/* 
	** calculate the transmembrane current 
	*/
	Field(I) = (v - Field(Vr)) * Field(G);

	break;
    case CHECK:
      n=0;
      MSGLOOP(channel,msg){
        case 0:
	  n +=1;
	  break;
      if(n != 1)
		{
	   	ErrorMessage(" inf_tau_chan","Missing v msg.",
			      channel);
		}
	break;
    case SAVE2:
        savedata[0] = channel->act;
        savedata[1] = channel->inact;
        /* action->data contains the file pointer */
        n=2;
        fwrite(&n,sizeof(int),1,(FILE*)action->data);
        fwrite(savedata,sizeof(double),2,(FILE*)action->data);
        break;
    case RESTORE2:
        /* action->data contains the file pointer */
        fread(&n,sizeof(int),1,(FILE*)action->data);
        if (n != 2) {
            ErrorMessage("inf_tau_chan.c", "Invalid savedata length", channel);
            return n;
        }
        fread(savedata,sizeof(double),2,(FILE*)action->data);
        channel->act = savedata[0];
        channel->inact = savedata[1];
        break;
    }
  }
}


