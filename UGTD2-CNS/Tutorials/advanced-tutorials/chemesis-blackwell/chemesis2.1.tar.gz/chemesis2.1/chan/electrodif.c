/* electrodif.c */
/* Avrama Blackwell, GMU, march 1998 */
/* computes current using the Goldman-Hodgkin-Katz Equation
  Then, computes and equivalent G and Vr to send to the compartment
  object.  Allows for modification of of GHK current by open fraction */

/* implements following equation:

define chi = (z*F)/(R*T*1000) - divide by 1000 to convert volts to millivolts
define coef = Pca*z*F*chi
I(V) = coef*v*(Conc_int - conc_ext*exp(-chi*v))/(1-exp(-chi*v))

when v = 0, implements equation determined by applying L'hopital's Rule:

I(V) = coef*v*(Conc_int - conc_ext*exp(-chi*v)*(1-chi*v)/(chi*exp(-chi*v))

Also, can modify Ica(V) by open fraction, which is sent as message from other channels:

I(V) = I(V) * open
*/

#include "chan_ext.h"
#define	Field(F) (channel->F)
#define R 8.31 /* j/mol-K */
#define F 96485 /* C/mol */

/*****************************************************************************/
electrodif(channel,action)
register struct GHK_type *channel;
Action		*action;
{
MsgIn	*msg;
float   quotient, eterm;
float   Cint, Cext;    /* temp storage of int & ext concentrations */
float   v;
float   G, Gbar;       /* conductance of Ohomic ICa, used to compute open fraction */

  SELECT_ACTION(action)
  {
    case INIT:
       channel->open = 1;
       break;
    case PROCESS:
       MSGLOOP(channel,msg) {
          case 0: /* External concentration */
	       Cext =  MSGVALUE(msg,0);
               Field(conc_ext) = Cext;
               break;
          case 1: /* Internal concentration */
	       Cint = MSGVALUE(msg,0);
	       Field(conc_int) = Cint;
	       break;
          case 2: /* voltage of compartment, must be in Millivolts */
	       v = MSGVALUE(msg,0);
	       Field(Vm) = v;
	       break;
          case 3: /* open fraction of channel */
	       G = MSGVALUE(msg,0);
	       Gbar = MSGVALUE(msg,1);
	       Field(open) = G / Gbar;
	       
               break;
       }

       eterm = exp(-v*Field(chi));
       if (fabs(v) > 1.0e-5)
	    quotient = v * (Cint - Cext * eterm) / (1 - eterm);
       else /* L'Hopital's rule if v is close to zero */
	     quotient = (Cint - Cext*eterm*(1-v*Field(chi)))/ (Field(chi)*eterm);

	Field(I) = Field(Pca)*Field(charge)*F*Field(chi)*quotient*Field(open);

/* Now, compute Vr and an equivalent conductance to send to compartment*/
	Field(Vr) = log(Field(conc_ext)/Field(conc_int))/Field(chi);
	Field(pseudoG) = Field(I) / (v - Field(Vr));

    break;
    
    case RESET:
       Field(chi) = Field(charge)*F*Field(Vunits)/(R*Field(T));
       MSGLOOP(channel,msg) {
          case 0: /* External concentration */
	       Cext =  MSGVALUE(msg,0);
               Field(conc_ext) = Cext;
               break;
          case 1: /* Internal concentration */
	       Cint = MSGVALUE(msg,0);
	       Field(conc_int) = Cint;
	       break;
          case 2: /* voltage of compartment, must be in Millivolts */
	       v = MSGVALUE(msg,0);
	       Field(Vm) = v;
	       break;
          case 3: /* open fraction of channel */
 	          /* message from channel object has value G/Gbar */
	       Field(open) = MSGVALUE(msg,0);
               break;
       }

        eterm = exp(-v*Field(chi));
	
	if (fabs(v) > 1.0e-5)
	     quotient = v * (Cint - Cext * eterm) / (1 - eterm);
	else
	     quotient = (Cint - Cext*eterm*(1-v*Field(chi)))/ (Field(chi)*eterm);

	Field(I) = Field(Pca)*Field(charge)*F*Field(chi)*quotient*Field(open);

/* Now, compute Er and an equivalent conductance to send to compartment*/
	Field(Vr) = log(Field(conc_ext)/Field(conc_int))/Field(chi);
	Field(pseudoG) = Field(I) / (v - Field(Vr));

    break;

    }
}
