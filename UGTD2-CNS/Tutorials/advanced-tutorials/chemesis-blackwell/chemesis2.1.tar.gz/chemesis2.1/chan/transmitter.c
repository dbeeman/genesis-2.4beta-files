#include "chan_ext.h"
#define	Field(F) (transm->F)
#define EXP 0
#define LIN 1

/*****************************************************************************/
/* transmitter (tranms, action)
   Computes the concentration of transmitter in the synapse.
   One of two simple models: linear or exponential decrease. */

transmitter(transm,action)
register struct transmitter_type *transm;
Action		*action;
{
MsgIn	*msg;
float	dt;		/* dt is float because Clockrate can be 0.01, 0.1, 1.0 etc */
static float	time;	/* the time is a float because dt is a float */
static float	elapsed_time;	/* time since start of transmitter */

    SELECT_ACTION(action)
    {
    
    case PROCESS:
	dt = Clockrate(transm);
	elapsed_time = simulation_time - transm->delay;
	
	if (elapsed_time >= 0)
	   {
		if (transm->decay_type == LIN)
		  transm->trans_conc = transm->peak * (1 - elapsed_time / transm->tau_fall);
		if (transm->decay_type == EXP)
		  transm->trans_conc = transm->peak * exp(-elapsed_time/transm->tau_fall);
		if (transm->trans_conc < 0) transm->trans_conc = 0;
	   }
	else
		transm->trans_conc = 0;
	break;
    
    case RESET:
    	time = 0;
    	transm->trans_conc = 0.0;
    	break;
    }
}
