/* chan_struct.h */

#include "struct_defs.h"

struct vdep_rate_const_type
{

/* formula for voltage dependent rate constant:
 *	rate_const(v) = min + max * 
 *	{out_exp_offset + exp[((v - v0)/slope)^in_exp_power + in_exp_offset]}
 *       ^out_exp_power
 *	
 *	for hh channels (Sigmoid type), 
 *		out_exp_power = -1, 
 *		in_exp_power = 1, 
 *		out_exp_offset = 1, 
 *		in_exp_offset = 0
 *      for voltage-independent channels make
 *               max = 0, 
 *               min = desired rate constant
 *               slope != 0
*/	
	float min;
	float max;
	float v0;
	float slope;
	float in_exp_power;
	float out_exp_power;
	float in_exp_offset;
	float out_exp_offset;
	float rate_const;
};

struct vdep_ligdep_rate_const_type
{

/* formula for voltage-dependent ligand-dependent rate constant:
 *	rate_const(v) = min + max * 
 *	{offset + exp[(v - v0)/slope]}^power
 *      where min = min_slp*f(Ca) + min_int
 *            max = max_slp*f(Ca) + max_int
 *            v0 = v0_slp*f(Ca) + v0_int
 *            slope = slope_slp*f(Ca) + slope_int
 *	
 *	for hh channels (Sigmoid type), 
 *		power = -1, 
 *		offset = 1
 *      for voltage-independent channels make
 *               max = 0, 
 *               min = desired rate constant
 *               slope != 0
 *      for linear functions of Ca make max = 0 (slope != 0)
*/	
        float min;
	float min_slp;
        float min_int;
        float max;
	float max_slp;
        float max_int;
        float v0;
	float v0_slp;
        float v0_int;
        float slope;
	float slope_slp;
        float slope_int;
	float power;
	float offset;
	float rate_const;
};

struct vdep_ligdep_chan_type
{
  SEGMENT_TYPE
  struct vdep_ligdep_rate_const_type act_ssv;     /* steady state activation */
  struct vdep_ligdep_rate_const_type act_tauv;	/* activation time constant */
  struct vdep_ligdep_rate_const_type inact_tauv;	/* inactivation time const. */
  struct vdep_ligdep_rate_const_type inact_ssv;	/* steady state inactivation */
  struct vdep_rate_const_type act_ssca;     /* steady state activation */
  struct vdep_rate_const_type act_tauca;	/* activation time constant */
  struct vdep_rate_const_type inact_tauca;	/* inactivation time const. */
  struct vdep_rate_const_type inact_ssca;	/* steady state inactivation */
  double act;    /* activation at time t */
  double inact;  /* inactivation at time t */
  float  act_power;
  float  inact_power;
  float  ligand; /* concentration of second messenger seen by channel */
  float Vr;      /* reversal potential of channel */
  float Vm;      /* voltage sensed by channel */
  float I;       /* channel  current */
  float G;       /* channel  conductance */
  float Gbar;    /* max channel conductance */
  int   inact_ss_type;
  int   inact_tau_type;
  int   act_tau_type;
  int   act_ss_type;    /* type of interaction of ligand and Voltage
		    0 = separable (vdep coef * ligdep coef
		    1 = nonseparable (vdep coef = f(ligand), linear
		    2 = nonseparable, log
		    3 = nonseparable, sigmoid */
};

struct vdep_chan_type
{
  SEGMENT_TYPE
  struct vdep_rate_const_type act_ss;     /* steady state activation */
  struct vdep_rate_const_type act_tau;	/* activation time constant */
  struct vdep_rate_const_type inact_tau;	/* inactivation time constant */
  struct vdep_rate_const_type inact_ss;	/* steady state inactivation */
  double inact;  /* inactivation at time t */
  double act;    /* activation at time t */
  float  act_power;
  float  inact_power;
  float Vr;      /* reversal potential of channel */
  float Vm;      /* voltage sensed by channel */
  float I;       /* channel  current */
  float G;       /* channel  conductance */
  float Gbar;    /* max channel conductance */
};

struct ligand1_chan_type
{
	SEGMENT_TYPE
	struct vdep_rate_const_type alpha; 	/* forward rate constant */
	struct vdep_rate_const_type beta;	/* backward constant */
	struct vdep_rate_const_type gamma; 	/* forward rate constant for lig-dep inact */
	struct vdep_rate_const_type delta;	/* backward constant for lig-dep inact*/
        struct vdep_rate_const_type inact_tau;	/* v dep inactivation time constant */
        struct vdep_rate_const_type inact_ss;	/* v dep steady state inactivation */
	float act_inf;		/* steady state activation */
	float act_tau;		/* activation time constant */
        float inact_inf;        /* steady state inact due to lig dep */
        float inact_rate;      /* inact rate const due to lig dep */
        float  act_power;
        float  inact_power;
        int  inact_type;        /* 0 for v dep, 1 for lig dep */
        double inact;           /* inactivation at time t */
        double act;	        /* activation at time t */
	float Vr;		/* reversal potential of channel */
	float Vm;		/* voltage sensed by channel */
	float ligand;		/* transmitter concentration seen by receptor */
        float modulator[4];        /* modulator of rate const. */
	float rxn_ord;		/* number of ligand molecules that bind receptor */
	float inact_rxn_ord;	/* number of ligand molecules that bind inactivation receptor */
	float I;		/* channel current */
	float G;		/* channel conductance */
	float Gbar;		/* max channel conductance */
};

struct ligand2_chan_type
{
	SEGMENT_TYPE
	float a11;		/* r1 c1 matrix value */
	float a12;		/* r1 c2 matrix malue */
	float a21;		/* r2 c1 matrix value */
	float a22;		/* r2 c2 matrix value */
	float b1;		/* r1 forcing fucntion */
	float b2;		/* r2 forcing fucntion */
	double TR1;		/* state 1 fraction */
	double TR2;		/* state 2 fraction */
	struct vdep_rate_const_type k2f; 	/* 2nd stage forward rate const */
	struct vdep_rate_const_type k2b;	/* 2nd stagebackward rate const */
	struct vdep_rate_const_type gamma; 	/* 3nd stage forward rate const */
	struct vdep_rate_const_type delta;	/* 3nd stagebackward rate const */
	struct vdep_rate_const_type k1f;	/* 1st stage forward rate const */
	struct vdep_rate_const_type k1b;	/* 1st stage backward rate const */
	float Vr;		/* reversal potential of channel */
	float Vm;		/* voltage sensed by channel */
	float ligand;		/* ligand concentration seen by channel */
	float rxn_ord1;		/* number of ligand molecules that bind first stage of receptor */
	float rxn_ord2;		/* number of ligand molecules that bind second stage of receptor */

	float I;		/* channel current */
	float G;		/* channel conductance */
	float Gbar;		/* max conductance of conducting state */
	int cond_state;		/* which state is the conducting state */
};

struct transmitter_type
{
	SEGMENT_TYPE
	float	trans_conc;	/* value of transmitter at time t */
	float	peak;		/* peak value of transmitter  */
	float	tau_fall;       /* decay time of transmitter */
  	int	decay_type;     /* 0 for exponential, 1 for linear */
  	float	delay;		/* time of arrival of transmitter */
};

struct GHK_type
{
  SEGMENT_TYPE
  float open;      /* open fraction of channel */
  float conc_ext;  /* external concentration of substance */
  float conc_int;  /* internal concentration of substance */
  float Vm;        /* voltage sensed by channel */
  float Vr;        /* reversal potential calculated by Nernst Eqn. */
  float pseudoG;   /* conductance to give equivalent current with Ohm's law */
  float I;         /* current through channel */
  float Pca;       /* permeability of channel */
  int charge;      /* charge of ion permeating channel */
  float chi;       /* RT/zF - stored to minimize computations */
  float T;         /* temperature in kelvin */
  float Vunits;    /* units of voltage. 1e-3 for mV */
};
  

