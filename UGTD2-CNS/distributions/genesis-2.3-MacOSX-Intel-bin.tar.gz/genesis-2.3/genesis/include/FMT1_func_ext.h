#ifndef FMT1_FUNC_EXT_H
#define FMT1_FUNC_EXT_H

/* Static IsA() method */
extern int	FMT1_IsA();
 
/*  Concrete Factory*/
extern Abs_Diskio*		FMT1_ConstructFile();

#endif
