#define xdialog_INPUT 0
#define xfastplot_NPLOT 0
#define xfastplot_WAVEPLOT 1
#define xfastplot_XPLOT 2
#define xfastplot_COLOR 3
#define xfastplot_UPDATE_DT 4
