static char rcsversion[] = "$Id: version.c,v 1.1.1.1 2005/06/14 04:38:39 svitak Exp $";

/*
* $Log: version.c,v $
* Revision 1.1.1.1  2005/06/14 04:38:39  svitak
* Import from snapshot of CalTech CVS tree of June 8, 2005
*
* Revision 1.1  1999/12/19 03:59:43  mhucka
* Adding PGENESIS from GENESIS 2.1 CDROM release.
*
* Revision 2.1  1997/07/31 04:27:00  ngoddard
* PGENESIS 2.1
*
* Revision 2.0  1997/03/01 04:44:25  ngoddard
* PGENESIS 2.0
*
* Revision 1.1  1995/04/03 22:04:49  ngoddard
* Initial revision
*
 * Revision 1.1  1994/09/07  19:01:00  ngoddard
 * passive messaging works, src figures map
 *
 * Revision 1.8  1993/12/30  04:05:01  ngoddard
 * parinit.o depend on version.c in Makefile!
 *
 * Revision 1.7  1993/12/30  03:56:54  ngoddard
 * added parinit.c dependency on version.c in Makefile
 *
 * Revision 1.6  1993/12/30  03:55:07  ngoddard
 * parinit.c, Makefile, and added Log keyword here
 *
*/

