#ifndef _IOFUNC_H_
#define _IOFUNC_H_

extern void iofunc();

#endif
