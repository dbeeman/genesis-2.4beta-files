/*
** $Id: seg_defs.h,v 1.1.1.1 2005/06/14 04:38:28 svitak Exp $
** $Log: seg_defs.h,v $
** Revision 1.1.1.1  2005/06/14 04:38:28  svitak
** Import from snapshot of CalTech CVS tree of June 8, 2005
**
** Revision 1.1  1992/12/11 19:04:13  dhb
** Initial revision
**
*/

#define		E_SPIKE				80

