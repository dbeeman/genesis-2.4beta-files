#include "struct_defs.h"

struct example_type {
    ELEMENT_TYPE
    float	input;
    float	output;
};

