/* $Id */
/* $Log */
#ifndef _xtemplate_struct_h
#define _xtemplate_struct_h

/*
 * #include "struct_defs.h"
 */
struct xtemplate_type {
	XWIDG_TYPE
	/* template specific fields go here */
};



#endif
