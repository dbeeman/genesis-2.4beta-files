/* $Id: sim_version.h,v 1.3 2005/11/27 02:42:17 svitak Exp $ */

#define VERSIONSTR	"2.4beta"
